import 'package:flutter/material.dart';

class SearchTop extends StatefulWidget {
  const SearchTop({Key? key}) : super(key: key);

  @override
  _SearchTopState createState() => _SearchTopState();
}

class _SearchTopState extends State<SearchTop> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // ignore: prefer_const_constructors
      backgroundColor: Color(0xffe5bc9d),
      body: SingleChildScrollView(
        child: SafeArea(
          child: Container(
            margin:
                const EdgeInsets.symmetric(vertical: 40.0, horizontal: 20.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: const [
                    SizedBox(
                      width: 80,
                      child: Text(
                        'Top Picks',
                        style: TextStyle(
                          fontFamily: 'Poppins',
                          fontWeight: FontWeight.w300,
                          fontSize: 27.0,
                          color: Colors.white,
                        ),
                      ),
                    ),
                    Icon(
                      Icons.shopping_cart_outlined,
                      color: Colors.white,
                      size: 27.0,
                    )
                  ],
                ),
                const SizedBox(
                  height: 5.0,
                ),
                Padding(
                  padding: const EdgeInsets.all(1.0),
                  child: TextField(
                    decoration: InputDecoration(
                      contentPadding:
                          const EdgeInsets.symmetric(vertical: 12.0),
                      fillColor: const Color(0xffFBF9F9),
                      filled: true,
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(15.0),
                        borderSide: const BorderSide(
                            width: 0.5, color: Color(0xffEF5350)),
                      ),
                      hintText: 'Search for ice cream',
                      hintStyle: const TextStyle(
                        fontSize: 18.0,
                        fontFamily: 'Poppins',
                        color: Color(0xfff7a1a1),
                      ),
                      prefixIcon: const Icon(
                        Icons.search,
                        size: 35.0,
                        color: Color(0xfff7a1a1),
                      ),
                    ),
                  ),
                ),
                const SizedBox(
                  height: 20.0,
                ),
                Column(
                  children: [
                    Row(
                      children: [
                        Expanded(
                          child: Stack(
                            // ignore: prefer_const_literals_to_create_immutables
                            children: [
                              Container(
                                width: 175.0,
                                height: 220.0,
                                decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(20),
                                    color: const Color(0xff6c5c4d)),
                              ),
                              const Positioned(
                                top: 10,
                                left: 10,
                                child: Icon(
                                  Icons.star_border,
                                  color: Colors.white,
                                  size: 25,
                                ),
                              ),
                              const Positioned(
                                top: 10,
                                right: 10,
                                child: Icon(
                                  Icons.shopping_cart_outlined,
                                  color: Colors.white,
                                  size: 25,
                                ),
                              ),
                              const Positioned(
                                top: 35,
                                left: 25,
                                child: Image(
                                  height: 120,
                                  width: 120,
                                  image: AssetImage('images/3.png'),
                                ),
                              ),
                              Positioned(
                                bottom: 10,
                                left: 10,
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: const <Widget>[
                                    Text(
                                      'Choco Scoop',
                                      style: TextStyle(
                                        fontFamily: 'Poppins',
                                        fontSize: 15.0,
                                        color: Colors.white,
                                        fontWeight: FontWeight.w400,
                                      ),
                                    ),
                                    SizedBox(
                                      width: 150,
                                      height: 30,
                                      child: Text(
                                        "ipsum dolor sit amet, consectiur",
                                        style: TextStyle(
                                          fontFamily: 'Poppins',
                                          fontSize: 11.0,
                                          //fontWeight: FontWeight.w400,
                                          color: Colors.white,
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              )
                              //Image(image: AssetImage('images/2.png'))
                            ],
                          ),
                        ),

                        const SizedBox(
                          width: 15.0,
                        ),

                        //Second Stack
                        Expanded(
                          child: Stack(
                            // ignore: prefer_const_literals_to_create_immutables
                            children: [
                              Container(
                                width: 175.0,
                                height: 220.0,
                                decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(20),
                                    color: const Color(0xffde8484)),
                              ),
                              const Positioned(
                                top: 10,
                                left: 10,
                                child: Icon(
                                  Icons.star_border,
                                  color: Colors.white,
                                  size: 25,
                                ),
                              ),
                              const Positioned(
                                top: 10,
                                right: 10,
                                child: Icon(
                                  Icons.shopping_cart_outlined,
                                  color: Colors.white,
                                  size: 25,
                                ),
                              ),
                              const Positioned(
                                top: 35,
                                left: 35,
                                child: Image(
                                  height: 120,
                                  width: 100,
                                  image: AssetImage('images/2.png'),
                                ),
                              ),
                              Positioned(
                                bottom: 10,
                                left: 10,
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: const <Widget>[
                                    Text(
                                      'Strawberry Scoops',
                                      style: TextStyle(
                                        fontFamily: 'Poppins',
                                        fontSize: 15.0,
                                        color: Colors.white,
                                        fontWeight: FontWeight.w400,
                                      ),
                                    ),
                                    SizedBox(
                                      width: 150,
                                      height: 30,
                                      child: Text(
                                        "ipsum dolor sit amet, consectiur",
                                        style: TextStyle(
                                          fontFamily: 'Poppins',
                                          fontSize: 11.0,
                                          //fontWeight: FontWeight.w400,
                                          color: Colors.white,
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              )
                            ],
                          ),
                        ),
                      ],
                    ),

                    const SizedBox(
                      height: 20.0,
                    ),
                    //LIne 2
                    Row(
                      children: [
                        //Third Stack
                        Expanded(
                          child: Stack(
                            // ignore: prefer_const_literals_to_create_immutables
                            children: [
                              Container(
                                width: 175.0,
                                height: 220.0,
                                decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(20),
                                    color: Color(0xff352f12)),
                              ),
                              const Positioned(
                                top: 10,
                                left: 10,
                                child: Icon(
                                  Icons.star_border,
                                  color: Colors.white,
                                  size: 25,
                                ),
                              ),
                              const Positioned(
                                top: 10,
                                right: 10,
                                child: Icon(
                                  Icons.shopping_cart_outlined,
                                  color: Colors.white,
                                  size: 25,
                                ),
                              ),
                              const Positioned(
                                top: 35,
                                left: 30,
                                child: Image(
                                  height: 120,
                                  width: 120,
                                  image: AssetImage('images/1.png'),
                                ),
                              ),
                              Positioned(
                                bottom: 10,
                                left: 10,
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: const <Widget>[
                                    Text(
                                      'Choco Stick',
                                      style: TextStyle(
                                        fontFamily: 'Poppins',
                                        fontSize: 15.0,
                                        color: Colors.white,
                                        fontWeight: FontWeight.w400,
                                      ),
                                    ),
                                    SizedBox(
                                      width: 150,
                                      height: 30,
                                      child: Text(
                                        "ipsum dolor sit amet, consectiur",
                                        style: TextStyle(
                                          fontFamily: 'Poppins',
                                          fontSize: 11.0,
                                          //fontWeight: FontWeight.w400,
                                          color: Colors.white,
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              )
                              //Image(image: AssetImage('images/2.png'))
                            ],
                          ),
                        ),

                        const SizedBox(
                          width: 15.0,
                        ),

                        //Fourth Stack
                        Expanded(
                          child: Stack(
                            // ignore: prefer_const_literals_to_create_immutables
                            children: [
                              Container(
                                width: 175.0,
                                height: 220.0,
                                decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(20),
                                    color: Color(0xffe2baba)),
                              ),
                              const Positioned(
                                top: 10,
                                left: 10,
                                child: Icon(
                                  Icons.star_border,
                                  color: Colors.white,
                                  size: 25,
                                ),
                              ),
                              const Positioned(
                                top: 10,
                                right: 10,
                                child: Icon(
                                  Icons.shopping_cart_outlined,
                                  color: Colors.white,
                                  size: 25,
                                ),
                              ),
                              const Positioned(
                                top: 35,
                                left: 35,
                                child: Image(
                                  height: 100,
                                  width: 100,
                                  image: AssetImage('images/4.png'),
                                ),
                              ),
                              Positioned(
                                bottom: 10,
                                left: 10,
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: const <Widget>[
                                    Text(
                                      'Strawberry Scoop',
                                      style: TextStyle(
                                        fontFamily: 'Poppins',
                                        fontSize: 15.0,
                                        color: Colors.white,
                                        fontWeight: FontWeight.w400,
                                      ),
                                    ),
                                    SizedBox(
                                      width: 150,
                                      height: 30,
                                      child: Text(
                                        "ipsum dolor sit amet, consectiur",
                                        style: TextStyle(
                                          fontFamily: 'Poppins',
                                          fontSize: 11.0,
                                          //fontWeight: FontWeight.w400,
                                          color: Colors.white,
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              )
                            ],
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(
                      height: 20.0,
                    ),
                    //LIne 2
                    Row(
                      children: [
                        //Third Stack
                        Expanded(
                          child: Stack(
                            // ignore: prefer_const_literals_to_create_immutables
                            children: [
                              Container(
                                width: 175.0,
                                height: 220.0,
                                decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(20),
                                    color: Color(0xff352f12)),
                              ),
                              const Positioned(
                                top: 10,
                                left: 10,
                                child: Icon(
                                  Icons.star_border,
                                  color: Colors.white,
                                  size: 25,
                                ),
                              ),
                              const Positioned(
                                top: 10,
                                right: 10,
                                child: Icon(
                                  Icons.shopping_cart_outlined,
                                  color: Colors.white,
                                  size: 25,
                                ),
                              ),
                              const Positioned(
                                top: 35,
                                left: 30,
                                child: Image(
                                  height: 120,
                                  width: 120,
                                  image: AssetImage('images/1.png'),
                                ),
                              ),
                              Positioned(
                                bottom: 10,
                                left: 10,
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: const <Widget>[
                                    Text(
                                      'Choco Stick',
                                      style: TextStyle(
                                        fontFamily: 'Poppins',
                                        fontSize: 15.0,
                                        color: Colors.white,
                                        fontWeight: FontWeight.w400,
                                      ),
                                    ),
                                    SizedBox(
                                      width: 150,
                                      height: 30,
                                      child: Text(
                                        "ipsum dolor sit amet, consectiur",
                                        style: TextStyle(
                                          fontFamily: 'Poppins',
                                          fontSize: 11.0,
                                          //fontWeight: FontWeight.w400,
                                          color: Colors.white,
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              )
                              //Image(image: AssetImage('images/2.png'))
                            ],
                          ),
                        ),

                        const SizedBox(
                          width: 15.0,
                        ),

                        //Fourth Stack
                        Expanded(
                          child: Stack(
                            // ignore: prefer_const_literals_to_create_immutables
                            children: [
                              Container(
                                width: 175.0,
                                height: 220.0,
                                decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(20),
                                    color: Color(0xffe2baba)),
                              ),
                              const Positioned(
                                top: 10,
                                left: 10,
                                child: Icon(
                                  Icons.star_border,
                                  color: Colors.white,
                                  size: 25,
                                ),
                              ),
                              const Positioned(
                                top: 10,
                                right: 10,
                                child: Icon(
                                  Icons.shopping_cart_outlined,
                                  color: Colors.white,
                                  size: 25,
                                ),
                              ),
                              const Positioned(
                                top: 35,
                                left: 35,
                                child: Image(
                                  height: 100,
                                  width: 100,
                                  image: AssetImage('images/4.png'),
                                ),
                              ),
                              Positioned(
                                bottom: 10,
                                left: 10,
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: const <Widget>[
                                    Text(
                                      'Strawberry Scoop',
                                      style: TextStyle(
                                        fontFamily: 'Poppins',
                                        fontSize: 15.0,
                                        color: Colors.white,
                                        fontWeight: FontWeight.w400,
                                      ),
                                    ),
                                    SizedBox(
                                      width: 150,
                                      height: 30,
                                      child: Text(
                                        "ipsum dolor sit amet, consectiur",
                                        style: TextStyle(
                                          fontFamily: 'Poppins',
                                          fontSize: 11.0,
                                          //fontWeight: FontWeight.w400,
                                          color: Colors.white,
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              )
                            ],
                          ),
                        ),
                      ],
                    ),
                  ],
                )
              ],
            ),
          ),
        ),
      ),
    );
  }
}


//Color Code
//#bcae85 